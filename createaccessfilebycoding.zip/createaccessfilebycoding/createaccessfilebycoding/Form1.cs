﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using ADOX;
using System.Data.OleDb;
namespace createaccessfilebycoding
{
    public partial class Form1 : Form
    {
        SaveFileDialog sfd = new SaveFileDialog();
        OpenFileDialog ofd = new OpenFileDialog();
        List<string> lstData = new List<string>();


        public Form1()
        {
            InitializeComponent();
        }

        private void btnLoadfile_Click(object sender, EventArgs e)
        {

            ofd.Filter = "Csv Files(*.csv)|*.csv|Text files(*.txt)|*.txt|All Files(*.*)|*.*";

            if (ofd.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {

                lstData = File.ReadAllLines(ofd.FileName).ToList();

                lstData.RemoveAt(0);  // removing header.

            }


        }

        private void btnProcess_Click(object sender, EventArgs e)
        {

            sfd.Filter = "Access file(*.accdb)|*.accdb";

            if (sfd.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                if (lstData.Count > 0)
                {

                    DataTable dt = new DataTable();
                    dt.Columns.Add("Employee_ID");
                    dt.Columns.Add("Full_Name");
                    dt.Columns.Add("Job_Title");
                    dt.Columns.Add("Department");
                    dt.Columns.Add("Gender");
                    dt.Columns.Add("Hire_Date");

                    lstData.ForEach(c =>
                    {
                        string[] data = c.Split(',');
                        DataRow dr = dt.NewRow();
                        dr["Employee_ID"] = data[0].ToString();
                        dr["Full_Name"] = data[1].ToString();
                        dr["Job_Title"] = data[2].ToString();
                        dr["Department"] = data[3].ToString();
                        dr["Gender"] = data[5].ToString();
                        dr["Hire_Date"] = data[8].ToString();
                        dt.Rows.Add(dr);

                    });

                    if (dt != null && dt.Rows.Count > 0)
                    {
                      bool flg=  CreateEmployeeAccessfile(dt, sfd.FileName);
                      if (flg)
                          MessageBox.Show("Accessfile generated successfully...", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }

            }

        }

        private bool CreateEmployeeAccessfile(DataTable dtemp, string filepath)
        {
            try
            {

                string accesspath = filepath.Substring(0, filepath.IndexOf(".")).Trim() + ".accdb";
                bool flg = false;

                var lstCols = Accesscolumns();


                if (!File.Exists(accesspath))
                {
                    ADOX.Catalog cat = new Catalog();
                    cat.Create(Convert.ToString("Provider=Microsoft.ACE.OLEDB.16.0;Data Source=") + accesspath);
                    ADOX.Table table = new Table();

                    table.Name = Path.GetFileNameWithoutExtension(accesspath);

                    if (lstCols.Count > 0)
                    {
                        lstCols.ForEach(c =>
                        {
                            ADOX.Column col = new Column();
                            col.Name = c;
                            col.Type = ADOX.DataTypeEnum.adVarWChar;
                            col.Attributes = ADOX.ColumnAttributesEnum.adColNullable;
                            table.Columns.Append(col);
                        });
                    }

                    //table.Columns.Append("Employee_ID", DataTypeEnum.adVarWChar);
                    //table.Columns.Append("Full_Name", DataTypeEnum.adVarWChar);
                    //table.Columns.Append("Job_Title", DataTypeEnum.adVarWChar);
                    //table.Columns.Append("Department", DataTypeEnum.adVarWChar);
                    //table.Columns.Append("Gender", DataTypeEnum.adVarWChar);
                    //table.Columns.Append("Hire_Date", DataTypeEnum.adVarWChar);

                    cat.Tables.Append(table);
                    cat = null;
                    flg = true;
                }


                string accessfilename = Path.GetFileNameWithoutExtension(accesspath);

                using (OleDbConnection conn = new OleDbConnection(Convert.ToString("Provider=Microsoft.ACE.OLEDB.16.0;Data Source=") + accesspath))
                {
                    using (OleDbDataAdapter dbadpter = new OleDbDataAdapter("SELECT * FROM " + accessfilename + "", conn))
                    {
                        dbadpter.InsertCommand = new OleDbCommand("Insert Into " + accessfilename + " ( [Employee_ID],[Full_Name],[Job_Title]"
                            + ",[Department],[Gender],[Hire_Date] ) Values (@Employee_ID, @Full_Name, @Job_Title, @Department, @Gender, @Hire_Date)");

                        lstCols.ForEach(x =>
                        {
                            dbadpter.InsertCommand.Parameters.Add("@" + x, OleDbType.WChar, 255).SourceColumn = x;
                        });

                        //dbadpter.InsertCommand.Parameters.Add ("@Employee_ID",  OleDbType.WChar , 255, "Employee_ID");


                        dbadpter.InsertCommand.Connection = conn;
                        dbadpter.InsertCommand.Connection.Open();
                        dbadpter.Update(dtemp);
                        dbadpter.InsertCommand.Connection.Close();
                    }
                }
                flg = true;
                return flg;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
                return false;
            }
        }


        private List<string> Accesscolumns()
        {
            List<string> lstcols = new List<string>();
            lstcols.Add("Employee_ID");
            lstcols.Add("Full_Name");
            lstcols.Add("Job_Title");
            lstcols.Add("Department");
            lstcols.Add("Gender");
            lstcols.Add("Hire_Date");
            return lstcols;
        }
    }
}

